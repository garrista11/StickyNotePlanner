import './App.css'
import React from 'react'
import { BrowserRouter as Router, Route} from 'react-router-dom'
import LogInPage from './pages/LogInPage'
import MainPage from './pages/MainPage'
import HelpPage from './pages/HelpPage'
import CreateUserPage from './pages/CreateUserPage'

function App() {
  return(
    <div className='App'>
      <Router>
        <div className='App-header'>
          <Route path="/" exact>
            <LogInPage />
          </Route>
          <Route path="/calendar">
            <MainPage />
          </Route>
          <Route path="/help">
            <HelpPage />
          </Route>
          <Route path="/newuser">
            <CreateUserPage />
          </Route>
        </div>
      </Router>
    </div>
  )
}

export default App;