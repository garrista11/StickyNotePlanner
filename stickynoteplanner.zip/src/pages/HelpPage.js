import React from 'react'

function HelpPage(){
    return (
        <div className='container'>
            <h2>Welcome to the help page!</h2>
            <h3>General information:</h3>
            <ul>
                <li>
                    There are no dates attached to the calendar, only days of the week! However,
                    you may add a date next to the title of your assignment info if you wish to!
                </li>
                <li>
                    Currently, there is no maximum to the number of sticky notes you may add to the calendar. If
                    you realize you have added too much, just clear the calendar!
                </li>
                <li>
                    Notes don't need to be placed on the calendar! Things like reminders can be
                    placed outside of the calendar.
                </li>
                <li>
                    If you would like to have multiple planners, try creating a second account!
                </li>
            </ul>
            <p>Have another question? Write it in the text box below along with a name so that
                we can answer your question!
            </p>
            <form>
                <label>
                    Question:
                    <input type="text" name="question"></input>
                </label>
                <label>
                    Name:
                    <input type="text" name="asker"></input>
                </label>
                <button type="submit">Submit Question</button>
            </form>
            <a href={'/calendar'}>Return to Plannner</a>
        </div>
    )
};

export default HelpPage;