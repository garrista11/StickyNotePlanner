import React from'react'

function LogInPage() {
    return(
        <div classsName="container">
            <h2>Welcome Back!</h2>
            <h3>Enter your username and password and press 'Log In'</h3>
            <h3>If you are new to the site, press 'Create New User'</h3>
            <form>
                <p>
                    <label>
                        Username:
                        <input type="text" name="name" />
                    </label>
                </p>
                <p>
                    <label>
                        Password:
                        <input type="password" name="password" />
                    </label>
                </p>
            </form>
            <a className="home-link" href={'calendar'}>Log In</a>
            <a className="home-link" href={'newuser'}>Create New User</a>
        </div>
    )
};

export default LogInPage;