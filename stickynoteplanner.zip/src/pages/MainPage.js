import '../App.css';
import React, {useState, useEffect} from 'react'
import Draggable from 'react-draggable'
import {v4 as uuidv4} from "uuid"
var randomColor = require("randomcolor");

function MainPage() {
  const [note, setNote] = useState("");
  const [notes, setNotes] = useState(
  JSON.parse(localStorage.getItem("notes")) || []
  );

  useEffect (() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  const keyPress = (event) => {
    var code = event.keyCode || event.which;
    if (code === 13) {
      newnote();
    }
  }

  const newnote = () => {
    if (note.trim() !== "") {
      const newnote = {
        id: uuidv4(),
        note: note,
        color: randomColor({luminosity: "light",}),
        defaultPos: { x:100, y:0},
      };
      setNotes((note) => [...note, newnote]);
      setNote("");
    } else {
      alert("Enter a note");
      setNote("");
    }
  };

  const updatePos = (data, index) => {
    let newArr = [...notes];
    newArr[index].defaultPos = { x: data.x, y: data.y };
    setNotes(newArr)
  };

  const deleteAll = () => {
    setNotes([])
  }
  const deleteNote = (id) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  return (
    <div className='App'>
      <h1>Sticky Note Planner :)</h1>
      <h3>Use the text box below the calendar to create new assignments and then
        drag them to the day they are due on!
      </h3>
      <div className='calendar-outline'>
        <table>
          <thead>
            <tr>
              <th>Monday</th>
              <th>Tueday</th>
              <th>Wednesday</th>
              <th>Thursday</th>
              <th>Friday</th>
              <th>Saturday</th>
              <th>Sunday</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className='new-note'>
        <input
          value = {note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Enter Assignment Name"
          onKeyPress={(e) => keyPress(e)}
        />
        <button onClick={newnote}>Create</button>
      </div>
      <div className='delete-notes'>
        <button onClick={() => { 
          if(window.confirm('Are you sure you wish to delete this item?')){
            deleteAll();
          }
           } }>Clear Notes</button>
      </div>
      <div className='navigation'>
        <p>
            <a href={'/'}>Log Out</a>
        </p>
        <p>
            <a href={'/help'}>Help!</a>
        </p>
      </div>
      
      <div id="notes">
        {notes.map((note, index) =>{
          return (
            <Draggable
            key={note.id}
            defaultPosition={note.defaultPos}
            onStop={(e, data) => {
              updatePos(data, index);
            }}
            >
              <div style={{ backgroundColor: note.color }} className='box'>
                <p style ={{ margin: 0 }}>{note.note}</p>
                <button id="delete" onClick={(e) => deleteNote(note.id)}>
                  X
                </button>
              </div>
            </Draggable>
          )
        })}
      </div>
      </div>
  );
}

export default MainPage;