import React from 'react'

function CreateUserPage(){
    return(
        <div className="container">
            <h2>Welcome! Thanks for using the Sticky Note Planner!</h2>
            <h3>Please enter a username and password</h3>
            <form>
                <p>
                    <label>
                        Username:
                        <input type="text" name="name" />
                    </label>
                </p>
                <p>
                    <label>
                        Password:
                        <input type="password" name="password"/>
                    </label>
                </p>
            </form>

            <a href={'/'}>Create!</a>
            <a href={'/'}>Return to Log In</a>
        </div>
    )
};

export default CreateUserPage;